import SplashScreen from '@/components/ui/SplashScreen';

export default function Loading() {
  return <SplashScreen />;
}