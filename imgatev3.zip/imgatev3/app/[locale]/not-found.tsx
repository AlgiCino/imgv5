export default function NotFound(){
  return (<div className="min-h-[60vh] flex items-center justify-center text-center"><div><h1 className="text-4xl font-extrabold text-gold">404</h1><p className="mt-4 text-gray-300">الصفحة غير موجودة</p></div></div>);
}
